var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
app.use(bodyParser.urlencoded({ extended: true }));
var path = require('path');
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

mongoose.connect('mongodb://localhost/dashboard');
mongoose.Promise = global.Promise;
var AnimalSchema = new mongoose.Schema({
 name: String,
 age: Number,
})
mongoose.model('Animal', AnimalSchema); // We are setting this Schema in our Models as 'User'
var Animal = mongoose.model('Animal')




app.get('/', function(req, res) {
  Animal.find({}, function(err, results) {
    if (err) { console.log(err); }
    res.render('index', { animals: results });
  })
})
app.get('/mongooses/:id', function(req, res) {
  Animal.find({ _id: req.params.id }, function(err, results) {
    if (err) { console.log(err); }
    res.render('mongoosesbyid', { animals: results });
  })
})
app.get('/mongoose/new', function(req, res) {
    res.render('new');
})
app.post('/mongooses', function(req, res) {
    console.log("POST DATA", req.body);
    var animal = new Animal({name: req.body.name, age: req.body.age});
    animal.save(function(err) {
    if(err) {
      console.log('something went wrong');
    } else { // else console.log that we did well and then redirect to the root route
      console.log('successfully added a user!');
      res.redirect('/');
    }
  })
})
app.get('/mongooses/edit/:id', function(req, res) {
  Animal.find({ _id: req.params.id }, function(err, results) {
    if (err) { console.log(err); }
    console.log(results)
    res.render('editbyid', { animals: results });
  })
})
app.post('/mongooses/:id', function(req, res) {
    console.log("POST DATA", req.body);
    Animal.findOne({ _id: req.params.id}, function(err, animal){
      animal.name = req.body.name;
      animal.age = req.body.age;

      animal.save(function(err){
        if(err) {
          console.log('something went wrong');
        } else { // else console.log that we did well and then redirect to the root route
          console.log('successfully added a user!');

        }
        res.redirect('/');
      })
    })
  })
app.post('/mongooses/destroy/:id', function(req, res) {
    console.log("POST DATA", req.body);
    Animal.remove({_id:req.params.id }, function(err){
      if(err) {
        console.log('something went wrong');
      } else { // else console.log that we did well and then redirect to the root route
        console.log('successfully deleted a user!');
      }
    })
    res.redirect('/');
})



app.listen(8000, function() {
    console.log("listening on port 8000");
})
