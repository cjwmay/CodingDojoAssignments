var mathlib = require('./mathlib')();
console.log(mathlib);
mathlib.add(5,6);
