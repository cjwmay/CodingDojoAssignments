//
//  ViewController.swift
//  presistent
//
//  Created by jingwen on 5/17/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit
import CoreData

class FirstTableViewController: UITableViewController, AddWordDelegate,EditWordDelegate {
    var words = [Word]()
    var idxcache: Int?
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchStuffs()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return words.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        cell.textLabel?.text = words[indexPath.row].title
        return cell
    }
    
    
    
    //fetch from coredata
    func fetchStuffs() {
        print("Fetching")
        let itemRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Word")
        do {
            // get the results by executing the fetch request we made earlier
            let results = try context.fetch(itemRequest)
            words = results as![Word]
            tableView.reloadData()
           
        } catch {
            // print the error if it is caught (Swift automatically saves the error in "error")
            print("\(error)")
        }
    }
    
    
    
    //--------
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "addVC", sender: indexPath.row)
    }
    override func tableView(_ tableView:UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        //delete
        //words.remove(at: indexPath.row)
        context.delete(words[indexPath.row])
        if context.hasChanges {
            do {
                try context.save()
                print("Success")
                fetchStuffs()
            } catch {
                print("\(error)")
            }
        }
        tableView.reloadData()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as!AddViewController
        if sender is Int{
            if let idx = sender as? Int{
                vc.wordToEdit = words[idx].title
                idxcache = idx
            }
            vc.editWordDel = self
        }else{
            vc.addWordDel = self
        }
    }
    func doneAdding() {
        //words.append(newWord)
        fetchStuffs()
        //tableView.reloadData()
    }
    func doneEditing(editedWord: String) {
        words[idxcache!].title=editedWord
        
        if context.hasChanges {
            do {
                try context.save()
                print("Success")
                fetchStuffs()
            } catch {
                print("\(error)")
            }
        }
        
        //tableView.reloadData()
    }


}

