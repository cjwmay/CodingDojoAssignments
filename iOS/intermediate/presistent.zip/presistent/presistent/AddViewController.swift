//
//  AddViewController.swift
//  presistent
//
//  Created by jingwen on 5/17/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit
import CoreData

class AddViewController: UIViewController {
    var addWordDel: AddWordDelegate?
    var wordToEdit: String?
    var editWordDel:EditWordDelegate?
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    @IBOutlet weak var AddWordOutlet: UITextField!
    
    @IBAction func CancelButtonPressed(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func SaveButtonPressed(_ sender: UIButton) {
        if (wordToEdit != nil){
            editWordDel?.doneEditing(editedWord: AddWordOutlet.text!)
        }else{
            let newWord = NSEntityDescription.insertNewObject(forEntityName: "Word", into: context) as! Word
            newWord.title = AddWordOutlet.text!
            if context.hasChanges {
                do {
                    try context.save()
                    print("Success")
                } catch {
                    print("\(error)")
                }
            }
            addWordDel?.doneAdding()
        }
        
        dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        if wordToEdit != nil{
           AddWordOutlet.text = wordToEdit
        }else{
            print("adding")
        }

        // Do any additional setup after loading the view.
    }


}
