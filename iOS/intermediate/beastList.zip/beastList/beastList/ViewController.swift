//
//  ViewController.swift
//  beastList
//
//  Created by jingwen on 5/11/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var task = [String]()

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var taskTextFielf: UITextField!
    @IBAction func beastButtonPressed(_ sender: UIButton) {
        task.append(taskTextFielf.text!)
        tableView.reloadData()
        taskTextFielf.text=""
        print(task)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return task.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Mycell", for: indexPath)
        cell.textLabel?.text = task[indexPath.row]
        return cell
    }
    
}
