//
//  AddViewDelegate.swift
//  madlib2
//
//  Created by jingwen on 5/17/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation

protocol AddViewDelegate: class {
    func addDone(w1: String, w2: String, w3: String, w4: String)
}
