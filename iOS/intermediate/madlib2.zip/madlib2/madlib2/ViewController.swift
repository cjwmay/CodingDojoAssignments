//
//  ViewController.swift
//  madlib2
//
//  Created by jingwen on 5/17/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class ViewController: UIViewController, AddViewDelegate {

    @IBOutlet weak var mainTextLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.mainTextLabel.text = "We are having a perfectly ____ time now. Later we will ____ and ____ in the ____"
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func addDone(w1: String, w2: String, w3: String, w4: String) {
        self.mainTextLabel.text = "We are having a perfectly \(w1) time now. Later we will \(w2) and \(w3) in the \(w4)"
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! AddViewController
        vc.addViewDelegate = self
    }


}

