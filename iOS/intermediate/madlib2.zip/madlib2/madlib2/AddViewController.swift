//
//  AddViewController.swift
//  madlib2
//
//  Created by jingwen on 5/17/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class AddViewController: UIViewController{
    var addViewDelegate: AddViewDelegate?

    @IBOutlet weak var w1: UITextField!
    @IBOutlet weak var w2: UITextField!
    @IBOutlet weak var w3: UITextField!
    @IBOutlet weak var w4: UITextField!
    @IBAction func submitButtonPressed(_ sender: UIButton) {
        self.addViewDelegate?.addDone(w1: w1.text!, w2: w2.text!, w3: w3.text!, w4: w4.text!)
        dismiss(animated: true, completion: nil)
    }

    @IBAction func cancelButtonPressed(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }


}
