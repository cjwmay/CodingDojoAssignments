//
//  AddTaskDelegate.swift
//  Exam
//
//  Created by jingwen on 5/25/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation

import UIKit
protocol BackButtonDelegate: class {
    func backButtonPressed(by controller: UIViewController)
}
