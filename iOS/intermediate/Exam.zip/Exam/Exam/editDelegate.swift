//
//  editDelegate.swift
//  Exam
//
//  Created by jingwen on 5/25/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation

import UIKit
protocol EditDelegate: class {
    func edit(index: Int)
}
