//
//  DirectionalDestinationViewControler.swift
//  nesw
//
//  Created by jingwen on 5/16/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class DirectionalDestinationViewControler: UIViewController {
    @IBOutlet weak var DirectionLabel: UILabel!
    
    var direction: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        DirectionLabel.text = direction
    }


}
