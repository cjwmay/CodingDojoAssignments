//
//  CustomCell.swift
//  binarycounter
//
//  Created by jingwen on 5/17/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation
import UIKit

protocol binaryTableCellDelegate: class {
    func valueChangedBy(value: Int)
}



class CustomCell: UITableViewCell {
    weak var delegate: binaryTableCellDelegate?
    @IBOutlet weak var middleLabel: UILabel!
    @IBAction func addButtonPressed(_ sender: UIButton) {
        var value = Int(middleLabel!.text!)
        delegate?.valueChangedBy(value: value!)
    }
    @IBAction func minusButtonPressed(_ sender: UIButton) {
        var value = Int(middleLabel!.text!)
        value = -value!
        delegate?.valueChangedBy(value: value!)
    }
    
    
    
    
}
