//
//  ViewController.swift
//  binarycounter
//
//  Created by jingwen on 5/17/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class CustomCellViewController: UIViewController {
    var total = 0

    @IBOutlet weak var totalLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
extension CustomCellViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 16
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BinaryCell", for: indexPath) as! CustomCell
        //cell.middleLabel.text = "\(nums[indexPath.row])"
        cell.delegate = self
        cell.middleLabel.text = String(describing: pow(10, indexPath.row))
        return cell
    }
    
}

extension CustomCellViewController: binaryTableCellDelegate{
    func valueChangedBy(value: Int){
        self.total += value
        self.totalLabel.text = "Total:\(self.total)"
    }
}
