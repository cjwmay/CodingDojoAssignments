//
//  AddDogViewController.swift
//  dogs
//
//  Created by jingwen on 5/19/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit
import CoreData

class AddDogViewController: UIViewController,UICollectionViewDataSource, UICollectionViewDelegate,AddDogDelegate {
    var items = [DogItems]()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    @IBOutlet weak var myCollectionView: UICollectionView!
    
    
    
    //make cells
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath) as! MyCell
        let dataforimage = items[indexPath.row].imageData!
        cell.imageDisplay.image = UIImage(data: dataforimage as Data)
        return cell
    }
    
    
    //segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if sender is Int{
            let destination = segue.destination as! DogsViewController
            destination.addDogDel = self
            let idx = sender as! Int
            destination.edititemname = items[idx].name!
            destination.edititemcolor = items[idx].color!
            destination.edititemtreat = items[idx].treat!
            destination.edititemimagedata = items[idx].imageData! as Data
            destination.edititem = items[idx]
            print(items[idx].name ?? "nil")
        }else{
            let destination = segue.destination as!DogsViewController
            destination.addDogDel = self
        }
    }
    //delegate protocal
    func doneAdding(by controller: UIViewController) {
        self.navigationController?.popViewController(animated: true)
        fetch()
        //dismiss(animated:true, completion: nil)
        
    }
    
    
    
    //select on cell func
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        performSegue(withIdentifier: "add", sender: indexPath.row)
    }

    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetch()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    
    //core data fetch func
    func fetch(){
        let itemRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "DogItems")
        do {
            let results = try context.fetch(itemRequest)
            items = results as! [DogItems]
            //for item in items {
            //    print("\(String(describing: item.name))")
            //}
            myCollectionView.reloadData()
        } catch {
            print("\(error)")
        }
        
    }


}
