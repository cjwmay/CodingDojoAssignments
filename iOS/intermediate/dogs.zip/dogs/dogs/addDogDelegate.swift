//
//  addDogDelegate.swift
//  dogs
//
//  Created by jingwen on 5/19/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation
import UIKit
protocol AddDogDelegate: class {
    func doneAdding(by controller: UIViewController)
}
