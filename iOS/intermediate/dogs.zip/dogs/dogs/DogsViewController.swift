//
//  DogsViewController.swift
//  dogs
//
//  Created by jingwen on 5/19/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit
import CoreData

class DogsViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    var edititemname: String?
    var edititemcolor: String?
    var edititemtreat: String?
    var edititemimagedata: Data?
    var edititem: DogItems?
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var image: UIImage?
    var addDogDel: AddDogDelegate?

    @IBOutlet weak var dogNameTextField: UITextField!
    @IBOutlet weak var dogColorTextField: UITextField!
    @IBOutlet weak var dogTreatTextField: UITextField!
    
    
    
    //Add img func
    @IBOutlet weak var imageView: UIImageView!
    @IBAction func addimageButtonPressed(_ sender: UIButton) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        
        let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a Source", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: {(action:UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera){
                imagePickerController.sourceType = .camera
                self.present(imagePickerController, animated: true, completion: nil)
            }else{
                print("Camera not available")
            }
        }))
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: {(action:UIAlertAction) in imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion: nil)}))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .default, handler: {(action:UIAlertAction) in}))
        self.present(actionSheet, animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        image = info[UIImagePickerControllerOriginalImage] as? UIImage
        imageView.image = image
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    // add dog func
    @IBAction func addDogButtonPressed(_ sender: UIButton) {
        if (edititem != nil){
            edititem?.name = dogNameTextField.text
            edititem?.color = dogColorTextField.text
            edititem?.treat = dogTreatTextField.text
            let imageData:NSData = UIImageJPEGRepresentation(image!, 1)! as NSData
            edititem?.imageData = imageData
            do {
                try context.save()
                print("Success")
            } catch {
                print("\(error)")
            }
            addDogDel?.doneAdding(by: self)
        }else{
            let dog = NSEntityDescription.insertNewObject(forEntityName: "DogItems", into: context) as! DogItems
            dog.name = dogNameTextField.text
            dog.color = dogColorTextField.text
            dog.treat = dogTreatTextField.text
            let imageData:NSData = UIImageJPEGRepresentation(image!, 1)! as NSData
            dog.imageData = imageData
            if context.hasChanges {
                do {
                    try context.save()
                    print("Success")
                } catch {
                    print("\(error)")
                }
            }
            addDogDel?.doneAdding(by: self)
        }
        
    }
    
    

    // go back to dogpage
    @IBAction func goBacktoDogButtonPressed(_ sender: UIBarButtonItem) {
        addDogDel?.doneAdding(by: self)
    }
    
    
    
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dogTreatTextField.placeholder = "treat"
        dogColorTextField.placeholder = "color"
        dogNameTextField.placeholder = "name"
        dogNameTextField.text = edititemname
        dogColorTextField.text = edititemcolor
        dogTreatTextField.text = edititemtreat
        imageView.image = UIImage(data: edititemimagedata!)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

