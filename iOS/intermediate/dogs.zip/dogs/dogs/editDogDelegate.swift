//
//  editDogDelegate.swift
//  dogs
//
//  Created by jingwen on 5/22/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation
import UIKit
protocol editDogDelegate {
    func selectedOnCell(at indexPath: NSIndexPath?)
}
