//
//  CancelButtonDelegate.swift
//  bl2
//
//  Created by jingwen on 5/16/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation
import UIKit

protocol CancelButtonDelegate: class {
    func cancelButtonPressed(by controller: UIViewController)
}
