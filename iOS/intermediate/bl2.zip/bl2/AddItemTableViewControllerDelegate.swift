//
//  AddItemTableViewControllerDelegate.swift
//  bl2
//
//  Created by jingwen on 5/16/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation

protocol AddItemTableViewControllerDelegate:class {
    func itemSaved(by controller: AddItemTableViewController, with text: String, at indexPath: NSIndexPath?)
    func cancelButtonPressed(by controller: AddItemTableViewController)
}
