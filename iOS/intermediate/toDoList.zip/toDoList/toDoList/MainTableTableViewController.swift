//
//  MainTableTableViewController.swift
//  toDoList
//
//  Created by jingwen on 5/18/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit
import CoreData

class MainTableTableViewController: UITableViewController,AddViewDelegate {
    
    var items = [ToDoListItem]()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        fetch()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    
    
    
    

    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return items.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! myCell
        cell.detailLabel?.text = items[indexPath.row].detail
        cell.dateLabel?.text = String(describing: items[indexPath.row].date!)
        cell.titleLabel?.text = items[indexPath.row].title
        if items[indexPath.row].finish == false{
            cell.accessoryType = UITableViewCellAccessoryType.none
        }else{
            cell.accessoryType = UITableViewCellAccessoryType.checkmark
        }
        return cell
    }
    
    //toggle finish
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        if items[indexPath.row].finish == false{
            items[indexPath.row].finish = true
        }else{
            items[indexPath.row].finish = false
        }
        if context.hasChanges {
            do {
                try context.save()
                print("Success")
            } catch {
                print("\(error)")
            }
        }
        fetch()
        tableView.reloadData()
    }
    
    
    
    //MARK:segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! AddViewController
        destination.addItemDel = self
    }
    
    //Protocol func
    func addItem() {
        fetch()
        tableView.reloadData()
    }
    
    //fetch
    func fetch(){
        let itemRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "ToDoListItem")
        do {
            let results = try context.fetch(itemRequest)
            items = results as! [ToDoListItem]
            for item in items {
                print("\(String(describing: item.title))")
            }
        } catch {
            print("\(error)")
        }
    }
    



}
