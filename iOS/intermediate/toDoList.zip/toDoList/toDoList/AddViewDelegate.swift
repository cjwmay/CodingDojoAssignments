//
//  AddViewDelegate.swift
//  toDoList
//
//  Created by jingwen on 5/18/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation


protocol AddViewDelegate: class {
    func addItem()
}
