//
//  myCell.swift
//  toDoList
//
//  Created by jingwen on 5/18/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation
import CoreData
import UIKit
class myCell: UITableViewCell {
    //Outlets

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    @IBOutlet weak var finishLabel: UILabel!
    
    
}
