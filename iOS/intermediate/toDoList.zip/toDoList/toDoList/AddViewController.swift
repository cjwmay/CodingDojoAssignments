//
//  AddViewController.swift
//  toDoList
//
//  Created by jingwen on 5/18/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit
import CoreData

class AddViewController: UIViewController {
    weak var addItemDel: AddViewDelegate?
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    //outlets
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var dateSelect: UIDatePicker!
    @IBOutlet weak var detialTextField: UITextField!
   
    
    
    //action
    
    @IBAction func addItemButtonPressed(_ sender: UIButton) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let item = NSEntityDescription.insertNewObject(forEntityName: "ToDoListItem", into: context) as! ToDoListItem
        item.title = titleTextField.text
        item.detail = detialTextField.text
        item.date = dateSelect.date as NSDate
        item.finish = false
        if context.hasChanges {
            do {
                try context.save()
                print("Success")
            } catch {
                print("\(error)")
            }
        }
        addItemDel?.addItem()
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    
    




}

