//
//  ViewController.swift
//  ColdCall2
//
//  Created by jingwen on 5/10/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let nameList = ["Brian","Antony","Cody","Andy","Micheal","Ryota"]

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var numLabel: UILabel!
    @IBAction func coldButtonPressed(_ sender: UIButton) {
        var num = String(arc4random_uniform(5)+1)
        var index = Int(arc4random_uniform(6))
        if num == "1"||num=="2"{
            numLabel.textColor = UIColor(red:1.0,green:0.0,blue:0.0,alpha:1.0)
        }
        else if num == "3"||num=="4"{
            numLabel.textColor = UIColor(red:1.0,green:0.5,blue:0.0,alpha:1.0)
        }
        else{
            numLabel.textColor = UIColor(red:0.0,green:1.0,blue:0.0,alpha:1.0)
        }
        nameLabel.text = nameList[index]
        numLabel.text = num
        numLabel.isHidden = false
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        numLabel.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


