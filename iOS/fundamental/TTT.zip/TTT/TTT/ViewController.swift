//
//  ViewController.swift
//  TTT
//
//  Created by jingwen on 5/10/17.
//  Copyright © 2017 jingwen. All rights reserved.
//
import UIKit

class ViewController: UIViewController {
    var num = 0
    var winList = [0,0,0,0,0,0,0,0]

    @IBOutlet weak var winLabel: UILabel!
    @IBOutlet var gridButton: [UIButton]!
    @IBAction func handleResetPressed(_ sender: UIButton) {
        for btn in gridButton{
            btn.backgroundColor = UIColor.gray
        }
        winList = [0,0,0,0,0,0,0,0]
        winLabel.text=""
    }

    @IBAction func changeColorPressed(_ sender: UIButton) {
        num+=1
        if num%2==0{
            sender.backgroundColor=UIColor.red
            if sender.tag == 1{
                winList[0]+=1
                winList[3]+=1
                winList[6]+=1
            }
            else if sender.tag == 2{
                winList[0]+=1
                winList[4]+=1
            }
            else if sender.tag == 3{
                winList[0]+=1
                winList[5]+=1
                winList[7]+=1
            }
            else if sender.tag == 4{
                winList[1]+=1
                winList[3]+=1
            }
            else if sender.tag == 5{
                winList[1]+=1
                winList[4]+=1
                winList[6]+=1
                winList[7]+=1
            }
            else if sender.tag == 6{
                winList[1]+=1
                winList[5]+=1
            }
            else if sender.tag == 7{
                winList[2]+=1
                winList[3]+=1
                winList[7]+=1
            }
            else if sender.tag == 8{
                winList[2]+=1
                winList[4]+=1
            }
            else if sender.tag == 9{
                winList[2]+=1
                winList[5]+=1
                winList[6]+=1
            }
            if winList.contains(3){
                winLabel.text="RedWin!"
            }
        }
        else{
            sender.backgroundColor=UIColor.blue
            if sender.tag == 1{
                winList[0]-=1
                winList[3]-=1
                winList[6]-=1
            }
            else if sender.tag == 2{
                winList[0]-=1
                winList[4]-=1
            }
            else if sender.tag == 3{
                winList[0]-=1
                winList[5]-=1
                winList[7]-=1
            }
            else if sender.tag == 4{
                winList[1]-=1
                winList[3]-=1
            }
            else if sender.tag == 5{
                winList[1]-=1
                winList[4]-=1
                winList[6]-=1
                winList[7]-=1
            }
            else if sender.tag == 6{
                winList[1]-=1
                winList[5]-=1
            }
            else if sender.tag == 7{
                winList[2]-=1
                winList[3]-=1
                winList[7]-=1
            }
            else if sender.tag == 8{
                winList[2]-=1
                winList[4]-=1
            }
            else if sender.tag == 9{
                winList[2]-=1
                winList[5]-=1
                winList[6]-=1
            }
            if winList.contains(-3){
                winLabel.text="BlueWin!"
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        for btn in gridButton{
            btn.backgroundColor = UIColor.gray
        }
        winLabel.text=""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

