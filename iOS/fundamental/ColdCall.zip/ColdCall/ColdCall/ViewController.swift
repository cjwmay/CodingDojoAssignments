//
//  ViewController.swift
//  ColdCall
//
//  Created by jingwen on 5/10/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    let nameList = ["Courtney","cody","Jay","Bryant","Amy","Jimmy"]
    @IBAction func callButtonPressed(_ sender: UIButton) {
        var num = Int(arc4random_uniform(6))
        nameLabel.text = nameList[num]
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


