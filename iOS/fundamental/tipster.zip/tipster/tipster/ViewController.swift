//
//  ViewController.swift
//  tipster
//
//  Created by jingwen on 5/11/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var groupsliderLabel: UISlider!
    @IBOutlet weak var tipsliderLabel: UISlider!
    @IBOutlet weak var groupLabel: UILabel!
    @IBOutlet weak var billLabel: UILabel!
    @IBOutlet var percentLabel: [UILabel]!
    @IBOutlet var tipLabel: [UILabel]!
    @IBOutlet var perpersonLabel: [UILabel]!
    var num = ""
    @IBAction func numberButtonPressed(_ sender: UIButton) {
        if sender.tag<0{
            num+="."
        }
        else{
            var a = String(sender.tag)
            num+=a
        }
        billLabel.text = num
        if let d = billLabel.text{
            var c = tipsliderLabel.value
            var x:Double = Double(d)!*Double(c-0.05)
            var y:Double = Double(d)!*Double(c)
            var z:Double = Double(d)!*Double(c+0.05)
            tipLabel[2].text = String(format: "%.2f",x)
            tipLabel[1].text = String(format: "%.2f",y)
            tipLabel[0].text = String(format: "%.2f",z)
            var j:Double = Double(Int(groupsliderLabel.value))
            perpersonLabel[2].text=String(format: "%.2f",x/j+Double(d)!/j)
            perpersonLabel[1].text=String(format: "%.2f",y/j+Double(d)!/j)
            perpersonLabel[0].text=String(format: "%.2f",z/j+Double(d)!/j)
        }
    }
    @IBAction func cButtonPressed(_ sender: UIButton) {
        billLabel.text="0"
        num = ""
        for tip in tipLabel{
            tip.text="0"
        }
        for person in perpersonLabel{
            person.text="0"
        }
        groupLabel.text="Group size:1"
        groupsliderLabel.value = 1
        tipsliderLabel.value = 0.15
    }
    @IBAction func groupSlider(_ sender: UISlider) {
        var i = Double(Int(sender.value))
        groupLabel.text = "Group Size:\(i)"
        if let f = billLabel.text{
            var g = tipsliderLabel.value
            var xxx:Double = Double(f)!*Double(g-0.05)
            var yyy:Double = Double(f)!*Double(g)
            var zzz:Double = Double(f)!*Double(g+0.05)
            perpersonLabel[2].text=String(format: "%.2f",xxx/i+Double(f)!/i)
            perpersonLabel[1].text=String(format: "%.2f",yyy/i+Double(f)!/i)
            perpersonLabel[0].text=String(format: "%.2f",zzz/i+Double(f)!/i)
        }
        
    }
    @IBAction func tipslider(_ sender: UISlider) {
        var b = sender.value
        percentLabel[0].text = String(Int(b*100+5))+"%"
        percentLabel[1].text = String(Int(b*100))+"%"
        percentLabel[2].text = String(Int(b*100-5))+"%"
        if let e = billLabel.text{
            var xx:Double = Double(e)!*Double(b-0.05)
            var yy:Double = Double(e)!*Double(b)
            var zz:Double = Double(e)!*Double(b+0.05)
            tipLabel[2].text = String(format: "%.2f",xx)
            tipLabel[1].text = String(format: "%.2f",yy)
            tipLabel[0].text = String(format: "%.2f",zz)
            var k:Double = Double(Int(groupsliderLabel.value))
            perpersonLabel[2].text=String(format: "%.2f",xx/k+Double(e)!/k)
            perpersonLabel[1].text=String(format: "%.2f",yy/k+Double(e)!/k)
            perpersonLabel[0].text=String(format: "%.2f",zz/k+Double(e)!/k)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        billLabel.text="0"
        tipLabel[2].text = "0.00"
        tipLabel[1].text = "0.00"
        tipLabel[0].text = "0.00"
        perpersonLabel[2].text="0.00"
        perpersonLabel[1].text="0.00"
        perpersonLabel[0].text="0.00"
        percentLabel[0].text="20%"
        percentLabel[1].text="15%"
        percentLabel[2].text="10%"
        groupLabel.text="Group size:1"
        groupsliderLabel.value = 1
        tipsliderLabel.value = 0.15
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


