//
//  ViewController.swift
//  NinjaGold
//
//  Created by jingwen on 5/10/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var score = 0
   
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var farmLabel: UILabel!
    @IBOutlet weak var caveLabel: UILabel!
    @IBOutlet weak var houseLabel: UILabel!
    @IBOutlet weak var csinoLabel: UILabel!
    @IBAction func buttonPressed(_ sender: UIButton) {
        if sender.tag == 1{
            var earn = Int(arc4random_uniform(11) + 10)
            farmLabel.text="You earned \(earn)"
            score = score+earn
            scoreLabel.text = "Score:\(score)"
            farmLabel.isHidden=false
            caveLabel.isHidden=true
            csinoLabel.isHidden=true
            houseLabel.isHidden=true
        }
        else if sender.tag == 2{
            var earn = Int(arc4random_uniform(6) + 5)
            caveLabel.text="You earned \(earn)"
            score = score+earn
            scoreLabel.text = "Score:\(score)"
            caveLabel.isHidden=false
            csinoLabel.isHidden=true
            houseLabel.isHidden=true
            farmLabel.isHidden=true
        }
        else if sender.tag == 3{
            var earn = Int(arc4random_uniform(4) + 2)
            houseLabel.text="You earned \(earn)"
            score = score+earn
            scoreLabel.text = "Score:\(score)"
            houseLabel.isHidden=false
            farmLabel.isHidden=true
            caveLabel.isHidden=true
            csinoLabel.isHidden=true
        }
        else if sender.tag == 4{
            var earn = Int(arc4random_uniform(51))
            var win = Int(arc4random_uniform(2))
            if win==0{
                csinoLabel.text="You lost \(earn)"
                earn=0-earn
                score = score+earn
                scoreLabel.text = "Score:\(score)"
            }
            else{
                csinoLabel.text="You earned \(earn)"
                score = score+earn
                scoreLabel.text = "Score:\(score)"
            }
            csinoLabel.isHidden=false
            farmLabel.isHidden=true
            caveLabel.isHidden=true
            houseLabel.isHidden=true
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        houseLabel.isHidden=true
        farmLabel.isHidden=true
        caveLabel.isHidden=true
        csinoLabel.isHidden=true
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

