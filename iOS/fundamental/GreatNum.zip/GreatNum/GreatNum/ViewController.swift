//
//  ViewController.swift
//  GreatNum
//
//  Created by jingwen on 5/11/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var a:Int = Int(arc4random_uniform(100)+1)

    @IBOutlet weak var windowButtonLabel: UIButton!
    @IBOutlet weak var windowLabel: UILabel!
    @IBOutlet weak var windowConstraint: NSLayoutConstraint!
    @IBOutlet weak var inputLabel: UITextField!
    @IBAction func submitPressed(_ sender: UIButton) {
        windowConstraint.constant = 250
        if inputLabel.text != nil{
            if Int(inputLabel.text!)!>a{
                print(a)
                windowLabel.text = "Incorrect\(String(describing: Int(inputLabel.text!)!)) is Too High"
                windowButtonLabel.setTitle("Guess Again", for: .normal)
            }
            else if Int(inputLabel.text!)!<a{
                print(a)
                windowLabel.text = "Incorrect\(String(describing: Int(inputLabel.text!)!)) is Too Low"
                windowButtonLabel.setTitle("Guess Again", for: .normal)
            }
            else{
                windowLabel.text = "Correct\(String(describing: Int(inputLabel.text!)!)) Was Correct!!!"
                windowButtonLabel.setTitle("Play Again", for: .normal)
                a=Int(arc4random_uniform(100)+1)
            }
            
        }
    }
    @IBAction func againButtonPressed(_ sender: UIButton) {
        windowConstraint.constant = -131
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        windowConstraint.constant = -131
        inputLabel.text = "0"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

