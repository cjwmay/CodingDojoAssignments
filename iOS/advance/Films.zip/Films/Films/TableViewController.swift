//
//  TableViewController.swift
//  Films
//
//  Created by jingwen on 5/23/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    var film = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        getAPI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return film.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = film[indexPath.row]
        return cell
    }
    
    
    func getAPI(){
        let url = URL(string: "http://swapi.co/api/films/")
        let session = URLSession.shared
        let task = session.dataTask(with: url!, completionHandler: {
            data, response, error in
            do {
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
                    //print(jsonResult)
                    if let results = jsonResult["results"] as? NSArray{
                        for result in results{
                            let filmDict = result as! NSDictionary
                            self.film.append(filmDict["title"]! as! String)
                            print(filmDict["title"]!)
                            print(self.film)
                        }
                    }
                }
                self.tableView.reloadData()
            } catch {
                print(error)
            }
        })
        task.resume()
    }
    


}

