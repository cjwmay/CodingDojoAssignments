//
//  PeopleViewController.swift
//  people
//
//  Created by jingwen on 5/22/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import UIKit
class PeopleViewController: UITableViewController {
    
    var people = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        callAPI(url: url!)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = people[indexPath.row]
        return cell
    }
    
    
    
    
    
var url = URL(string: "http://swapi.co/api/people/")
    func callAPI(url:URL){
        let session = URLSession.shared
        DispatchQueue.global(qos: DispatchQoS.userInitiated.qosClass).async{
            
        }
        let task = session.dataTask(with: url, completionHandler: {
        data, response, error in
        print("in here")
        print(data ?? "no data")
        do{
            if let jasonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary{
                if let results = jasonResult["results"] as? NSArray{
                    for person in results{
                        let personDict = person as! NSDictionary
                        self.people.append(personDict["name"]! as! String)
                        print(personDict["name"]!)
                    }
                }
                if let n = jasonResult["next"] {
                    if n is NSNull {
                        
                    } else {
                        if let urlnext = URL(string: n as! String){
                            self.callAPI(url: urlnext)
                        }
                    }
                }
            }
            self.tableView.reloadData()
        }catch{
            print(error)
        }
    })
        task.resume()
    }
}




