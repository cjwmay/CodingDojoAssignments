//
//  doneAddingDelegate.swift
//  exam_Jingwen
//
//  Created by jingwen on 5/30/17.
//  Copyright © 2017 jingwen. All rights reserved.
//

import Foundation
import UIKit
protocol doneAdding {
    func doneAdding()
}
